<div class="col-12  d-lg-none d-xl-none d-md-none btn btn-success "  >
    <a href="#"style="color:#fff; font-size:24px;" target="blank"> সুবর্ণ জয়ন্তী ও  বঙ্গবন্ধু কর্ণার   </a>
  </div>

  <div class="container">
    <div class="col-sm-12 col-12 bg-white p-0 pt-5">
      <img src="frontend/assets/img/footer_top_bg.png" class="img-fluid w-100">
    </div>
    <div class="col-sm-12 col-12 developerdiv">
      <center>
      <span class="develop">Developed by</span>&nbsp;&nbsp;<a href="http://bytebd.net/" target="blank" class="it">BYTEBD.NET</a></center>
    </div>
    <!-----------end develop by---------->
  </div>