<div class="col-md-12 col-12 p-0 mt-3 about">
    <ul class="list-group p-0">
      <li class="list-group-item" id="header">প্রতিষ্ঠান সম্পর্কে</li>
      <div class="details2 p-2 border">
          <title>প্রতিষ্ঠান সম্পর্কে</title>
          <p>{!! $aboutschool->content !!}</p>
      </div>
      <a href="/About_school" class="btn btn-success btn-sm">আরো পড়ুন...</a>
    </ul>
  </div>