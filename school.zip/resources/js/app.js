import './bootstrap';
// import 'laravel-datatables-vite';
import 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
