

<?php $__env->startSection('content'); ?>

<div class="col-sm-9 col-12">
    <div class="col-sm-12 col-12 p-0"  data-aos="fade-in" data-aos-duration="2000" >
       <ul class="list-group p-0">
        <li class="list-group-item font-weight-bold bg-success text-light" id="about">সিটিজেন চার্টার</li>
      </ul>
      <li class="list-group-item">
        <div style="font-size: 14px; line-height: 25px; text-align: justify;">
          <?php if($Citizencharter->image): ?>
            <img class="w-25" src="<?php echo e(asset($Citizencharter->image)); ?>" alt="">
          <?php endif; ?>
            <p><?php echo $Citizencharter->content; ?></p>
       </div>
     </li>
   </div>
 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school\resources\views/frontend/about/Citizen_charter.blade.php ENDPATH**/ ?>