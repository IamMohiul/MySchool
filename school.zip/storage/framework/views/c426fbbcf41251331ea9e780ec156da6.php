<div class="col-sm-3 col-12">
    <div class="col-sm-12 col-12 p-0">
      <ul class="list-group">
        <li class="list-group-item" id="featureheads">সভাপতির বাণী</li>
      </ul>
      <li class="list-group-item p-0 pt-2" id="padd">
        <a href="#"><center><img src="frontend/assets/otherimage/chairman.jpg" class="img-fluid" style="max-height: 200px;padding-bottom:5px;"></center></a>
        <center><span class="head">Name<br><a href="#" class="btn btn-success btn-sm btn-block">বিস্তারিত</a></span></center>
      </li>
    </div>
    <div class="col-sm-12 col-12 p-0" style="margin-top:10px;">
      <ul class="list-group">
        <li class="list-group-item" id="featureheads">প্রধান শিক্ষকের বাণী</li>
      </ul>
      <li class="list-group-item p-0 pt-2" id="padd">
        <a href="#"><center><img src="frontend/assets/otherimage/headteacher.jpg" class="img-fluid" style="max-height: 200px;padding-bottom:5px;"></center></a>
        <center><span class="head">অজিত কুমার তরফদার<br><a href="#" class="btn btn-success btn-sm btn-block">বিস্তারিত</a></span></center>
      </li>
    </div>
    <div class="col-sm-12 col-12 p-0 mt-3" data-aos="fade-in" data-aos-duration="1000">
      <ul class="list-group">
        <li class="list-group-item" id="featureheads">গুরুত্বপূর্ণ লিংক</li>
      </ul>
      <div class="feature">
        <a href="http://www.ntrca.gov.bd/" target="_blank"><li style='font-size:12px;'><span uk-icon="icon: triangle-right; ratio: 0.7"></span>&nbsp;&nbsp;এনটিআরসিএ</li></a>
        <a href="http://www.dshe.gov.bd/" target="_blank"><li style='font-size:12px;'><span uk-icon="icon: triangle-right; ratio: 0.7"></span>&nbsp;&nbsp;মাধ্যমিক ও উচ্চশিক্ষা অধিদপ্তর</li></a>
        <a href="http://www.moedu.gov.bd/" target="_blank"><li style='font-size:12px;'><span uk-icon="icon: triangle-right; ratio: 0.7"></span>&nbsp;&nbsp;শিক্ষা মন্ত্রণালয়</li></a>
        <a href="https://dhakaeducationboard.gov.bd/" target="_blank"><li style='font-size:12px;'><span uk-icon="icon: triangle-right; ratio: 0.7"></span>&nbsp;&nbsp;মাধ্যমিক ও উচ্চমাধ্যমিক শিক্ষা বোর্ড, ঢাকা</li></a>
        <a href="http://nctb.gov.bd/" target="_blank"><li style='font-size:12px;'><span uk-icon="icon: triangle-right; ratio: 0.7"></span>&nbsp;&nbsp;National Text Book Board (NCTB)</li></a>
        <a href="http://emis.gov.bd/emis" target="_blank"><li style='font-size:12px;'><span uk-icon="icon: triangle-right; ratio: 0.7"></span>&nbsp;&nbsp;EMIS</li></a>
        <a href="http://dshe.mmcm.gov.bd/" target="_blank"><li style='font-size:12px;'><span uk-icon="icon: triangle-right; ratio: 0.7"></span>&nbsp;&nbsp;Multimedia Classroom Management</li></a>
        <a href="https://teachers.gov.bd/" target="_blank"><li style='font-size:12px;'><span uk-icon="icon: triangle-right; ratio: 0.7"></span>&nbsp;&nbsp;শিক্ষক বাতায়ন</li></a>
      </div>
    </div>
    <div class="col-sm-12 col-12 p-0 mt-2">
      <ul class="list-group">
        <li class="list-group-item" id="featureheads"> গুগল ম্যাপ </li>
      </ul> 
      <li class="list-group-item p-0 pt-2" id="padd" style="overflow: hidden">
        <center>
        
        <br></center>
      </li>
    </div>
    <div class="col-sm-12 col-12 p-0 mt-2">
      <ul class="list-group">
        <li class="list-group-item" id="featureheads">অফিসিয়াল ফ্যান পেইজ</li>
          <li class="list-group-item p-0 pt-2" id="padd">
          <center>
          <iframe src="https://www.facebook.com/plugins/page.php?href=https://www.facebook.com/p/Moulovi-Abdur-Rahman-High-School-মৌলভী-আব্দুর-রহমান-উচ্চ-বিদ্যালয়-টেপরী-100067220900017/&amp;tabs=timeline&amp;width=250&amp;height=300&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId=338704303143050" width="250" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
        </li>
      </ul> 
    </div>
    <div class="col-sm-12 col-12 p-0 mt-3" data-aos="fade-in" data-aos-duration="1000">
      <ul class="list-group">
        <li class="list-group-item" id="featurehead">জাতীয় সংগীত</li>
        <iframe width="100%" height="150" src="https://www.youtube.com/embed/SjefET6W3q4?start=13" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </ul>
    </div>
  </div><?php /**PATH C:\laragon\www\school\resources\views/frontend/sections/sidenav/sidenav.blade.php ENDPATH**/ ?>