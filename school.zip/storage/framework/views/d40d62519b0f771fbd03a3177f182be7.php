<div class="col-sm-12 col-12 p-0 pb-2 cnotice">
    <div class="row">
      <div class="col-md-2 col-12 d-sm-block d-none">
        <img src="frontend/assets/img/notice.png" class="img-fluid">
      </div>
      <div class="col-md-10 col-11 pt-3 p-4">
        <strong class="text-success">নোটিশ বোর্ড</strong><br>
        <div class="mt-3">       
          <li><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;&nbsp;<a href="notice-view/109.html" >১লা অক্টবর থেকে দশম শ্রেণির নির্বাচনি পরীক্ষা শুরু হবে।</a></li>
          <li><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;&nbsp;<a href="notice-view/106.html" >এসএসসি&#039;২৪ নির্বাচনী পরীক্ষা সংক্রান্ত</a></li>
          <li><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;&nbsp;<a href="notice-view/105.html" >নির্বাচনী পরীক্ষার নোটিশ</a></li>
          <li><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;&nbsp;<a href="notice-view/103.html" >বার্ষিক পরীক্ষার ফলাফল প্রকাশ</a></li>
          <li><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;&nbsp;<a href="notice-view/102.html" >ইউনিক আইডি</a></li>     
        </div>
        <div class="mt-4">
          <a href="Notices.html" class="float-right all">সকল নোটিশ</a>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\laragon\www\school\resources\views/frontend/sections/notice.blade.php ENDPATH**/ ?>