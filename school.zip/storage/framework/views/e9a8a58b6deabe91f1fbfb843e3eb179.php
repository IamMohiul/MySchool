

<?php $__env->startSection('content'); ?>

<div class="col-sm-9 col-12">
    <div class="col-sm-12 col-12 p-0"  data-aos="fade-in" data-aos-duration="2000" >
       <ul class="list-group p-0">
        <li class="list-group-item font-weight-bold bg-success text-light" id="about">প্রতিষ্ঠান সম্পর্কে</li>
      </ul>
      <li class="list-group-item">
        <div style="font-size: 14px; line-height: 25px; text-align: justify;">
            <h1> This is Heading</h1>
            <p>This is a paragraph.</p>
       </div>
     </li>
   </div>
 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school\resources\views/frontend/administrative/Managing_comittee.blade.php ENDPATH**/ ?>