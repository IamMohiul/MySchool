

<?php $__env->startSection('content'); ?>

        <!-- Main Page Start-->
        <div class="col-sm-9 col-12">
          <!--Notice Board-->
          <?php echo $__env->make('frontend.sections.notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <!-------------End Notice---------->
            <!--About Us -->
          <?php echo $__env->make('frontend.sections.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <!--End of About Us-->
          <!--Card section-->
          <?php echo $__env->make('frontend.sections.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <!-- End Card Section-->
          <!-- Featured Section -->
          <?php echo $__env->make('frontend.sections.featured', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <!--End Featured Section-->
        </div>
        <!-------------End Mainpage----------->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school\resources\views/frontend/home.blade.php ENDPATH**/ ?>