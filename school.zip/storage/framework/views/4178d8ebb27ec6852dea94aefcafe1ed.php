<div> 
    <div style="margin-top: 20px;">
      <iframe width="100%" height="400" src="https://www.youtube.com/embed/gxDjLQj4xkg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
</div><?php /**PATH C:\laragon\www\school\resources\views/frontend/sections/featured.blade.php ENDPATH**/ ?>